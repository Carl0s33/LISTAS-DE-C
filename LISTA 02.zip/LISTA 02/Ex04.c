//Faça um programa que leia 3 números e mostre se o valor de sua soma é par ou ímpar.

#include <stdio.h>

int main() {
  int num1, num2, num3, soma;
  
  printf("Digite 3 números inteiros: \n");
  scanf("%i %i %i", &num1, &num2, &num3);
  
   soma = num1 + num2 + num3;
  
  if (soma % 2 == 0) {
    printf("A soma dos números é par.");
    } else {
        printf("A soma dos números é ímpar.");
    }   
}
