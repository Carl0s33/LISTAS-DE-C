//Faça um programa que leia um número e mostre se ele é par ou ímpar.

#include <stdio.h>

int main() {
  int num;
  
  printf("Digite um número: ");
  scanf("%i", &num);
  
  if (num % 2 == 0) {
    printf("O número é par.");
  } else {
    printf("O número é ímpar.");
  }
  
  return 0;
}