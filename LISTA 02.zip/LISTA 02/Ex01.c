//Faça um programa que leia 3 números inteiros e apresente o menor deles.

#include <stdio.h>

int main() {
  int num1, num2, num3;
  
  printf("Digite 3 números inteiros: \n");
  scanf("%i %i %i", &num1, &num2, &num3);
  
  if (num1 < num2 && num1 < num3) {
    printf("O menor número é: %i", num1);
    } else if (num2 < num1 && num2 < num3) {
    printf("O menor número é: %i", num2);
    } else {
        printf("O menor número é: %i", num3);
    }   

    return 0;
}