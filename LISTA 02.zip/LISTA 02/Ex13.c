//13. Elabore um programa em que dada a idade de um nadador classifique-o em uma das seguintes
//categorias:

#include <stdio.h>
#include <stdlib.h>

int main() {
    system("cls");
    
    int idade;
    
    printf("Digite sua idade: ");
    scanf("%d", &idade);
    
    if(idade >= 5 && idade <= 7){
        printf("Infantil A");
    }else if(idade >= 8 && idade <= 10){
        printf("Infantil B");
    }else if(idade >= 11 && idade <= 13){
        printf("Juvenil A");
    }else if(idade >= 14 && idade <= 17){
        printf("Juvenil B");
    }else if(idade >= 18){
        printf("Adulto");
    }
 else if (idade < 1 || idade > 120){

        printf("Erro! Idade invalida");
    }
else {
        printf("Voce nao tem idade para nadar");
    }
    return 0;
}
