//Faça um programa que calcule a média entre 3 notas se e somente se essas notas forem válidas.
//Uma nota é considerada válida se ela for maior ou igual a zero e menor ou igual a cem (0<= nota
//<=100)

#include <stdio.h>

int main() {
  float nota1, nota2, nota3, media;
  
  printf("Digite 3 notas: \n");
  scanf("%f %f %f", &nota1, &nota2, &nota3);
  
  if (nota1 >= 0 && nota1 <= 100 && nota2 >= 0 && nota2 <= 100 && nota3 >= 0 && nota3 <= 100) {
    media = (nota1 + nota2 + nota3) / 3;
    printf("A media eh: %.2f", media);
  } 
  else {
    printf("Uma ou mais das notas sao invalidas.");
  }

  return 0;
}