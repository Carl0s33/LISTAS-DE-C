#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int a = 10;
    int b = 20;
    int c = 30;

    printf("Valor de a: %i\n", a);
    printf("Valor de b: %i\n", b);
    printf("Valor de c: %i\n", c);

    return 0;
}

