//Solicite um número e verifique se ele é negativo, caso seja verifique se ele é par ou ímpar e exiba
//o número e se é par ou ímpar.

#include <stdio.h>

int main() {
  int num;
  
  printf("Digite um número: ");
  scanf("%d", &num);
  
  if (num < 0) {
    if (num % 2 == 0) {
      printf("O número %d é negativo e par.", num);
    } else {
      printf("O número %d é negativo e ímpar.", num);
    }
  } else {
    if (num % 2 == 0) {
      printf("O número %d é positivo e par.", num);
    } else {
      printf("O número %d é positivo e ímpar.", num);
    }
  }
  
  return 0;
}