//15. Faça um programa que leia 3 valores e verifique se todos são inteiros e positivos, em seguida
//exiba quais deles são inteiros ou não e positivos ou negativos.

#include <stdio.h>
#include <stdlib.h>

int main() {
    int num1, num2, num3;
    
    printf("Digite 3 números inteiros: \n");
    scanf("%d %d %d", &num1, &num2, &num3);
    
    if (num1 % 1 == 0 && num2 % 1 == 0 && num3 % 1 == 0) {
        printf("Todos os números são inteiros.\n");
    } else {
        printf("Pelo menos um dos números não é inteiro.\n");
    }
    
    if (num1 >= 0 && num2 >= 0 && num3 >= 0) {
        printf("Todos os números são positivos.\n");
    } else {
        printf("Pelo menos um dos números não é positivo.\n");
    }
    
    return 0;
}
