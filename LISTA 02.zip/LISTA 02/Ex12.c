//Faça um programa que leia um número, calcule e exiba se ele é divisível por 2 e 5.

#include <stdio.h>
#include <stdlib.h>

    int main() {
    system("cls");

    int num;

    printf("Digite um número: ");
    scanf("%i", &num);

    if (num % 2 == 0 && num % 5 == 0) {
        printf("O número %i é divisível por 2 e 5.", num);
    } else {
        printf("O número %i não é divisível por 2 e 5.", num);
    }

    return 0;
}