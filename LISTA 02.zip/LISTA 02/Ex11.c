//Faça um programa que receba o peso e a altura de um usuário e calcule o IMC (índice de massa
//corpórea). O IMC é definido por peso / (altura * altura). Escreva no console a situação do
//paciente baseada na tabela abaixo//.

#include <stdio.h>
#include <stdlib.h>

int main(){
    system("cls");
    float peso, altura, imc;
    printf("Digite o peso: ");
    scanf("%f", &peso);
    printf("Digite a altura: ");
    scanf("%f", &altura);
    imc = peso / (altura * altura);
    printf("Seu IMC eh: %.2f \n", imc);
    if(imc < 18.5){
        printf("vc esta abaixo do peso ideal\n");
    }
    
    else if(imc >= 18.5 && imc < 24.9){
        printf("Parabens, vc esta em seu peso normal!\n");
    }

    else if(imc >= 25 && imc < 29.9){
        printf("vc esta acima do peso ideal\n");
    }

    else if(imc >= 30 && imc < 34.9){
        printf("Obesidade grau I\n");
    }
    
    else if(imc >= 35 && imc < 39.9){
        printf("Obesidade grau II\n");
    }
    
    else{
        printf("Obesidade grau III\n");
    }
    return 0;
}

