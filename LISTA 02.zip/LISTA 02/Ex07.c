//Faça um programa que leia um número e verifique se ele está no intervalo de 5 e 9. Caso esteja,
//informe ao usuário.

#include <stdio.h>
#include <stdlib.h>

int main() {
    system("cls");
    int numero;
    
    printf("Digite um numero: ");
    scanf("%i", &numero);
    
    if (numero >= 5 && numero <= 9) {
        printf("O numero %i esta no intervalo de 5 a 9.", numero);
    } else {
        printf("O numero %i nao esta no intervalo de 5 a 9.", numero);
    }
    
    return 0;
}