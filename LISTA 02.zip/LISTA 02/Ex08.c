//Solicite um número ao usuário e verifique se o número é -5 ou 5. Exiba em tela caso seja
//verdadeiro, senão exibir uma mensagem de erro.

#include <stdio.h>

int main() {
    int num;
    printf("Digite um numero: ");
    scanf("%i", &num);

    if (num == -5 || num == 5) {
        printf("Verdadeiro");
    } else {
        printf("Falso");
    }

    return 0;
}
