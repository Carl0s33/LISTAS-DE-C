//5. Faça um programa que leia um número e mostre se ele é positivo ou negativo.


#include <stdio.h>

int main() {
    int num;
    
    printf("Digite um numero: ");
    scanf("%i", &num);
    
    if (num >= 0) {
        printf("O numero %i eh positivo", num);
    } else {
        printf("O numero %i eh negativo", num);
    }
    
    return 0;
}